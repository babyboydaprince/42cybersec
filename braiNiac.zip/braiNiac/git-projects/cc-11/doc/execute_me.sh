{ sleep 1 ; echo -n 'starwars'; printf '\r'; sleep 99999 ;} | telnet telehack.com 23
